package com.example.webfinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfinanceApplicationTests {

    @Test
    void contextLoads() {
    }

}
