package com.example.webfinance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class WebfinanceApplication {

    public static void main(String[] args) {

        SpringApplication.run(WebfinanceApplication.class, args);
    }

}
