package com.example.webfinance;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Component
@RestController
@RequestMapping(value = "/stock", method = GET)
public class Stock {

    private String stock = "GOOG";
    public String setStockMessage = "http://localhost:8080/stock/api/stock?stock={TICKER} <-- Replace TICKER with symbol";

    /**
     * http://localhost:8080/stock/api/stock?stock=MSFT
     * @param stock
     */
    @GetMapping("/api/stock")
    public String setStock(String stock) throws MalformedURLException {
        this.stock = stock;
        return "The stock is now set to " + this.stock + ". Go back + " + new URL("http://localhost:8080/stock/code");
    }

    /**
     * http://localhost:8080/stock/code
     * @param args
     * @return
     */
    @GetMapping(value = "/code")
    @ResponseBody
    public String main(String[] args) {

        Document doc;
        try {
            var header = "";
            var prices = "";

            // need http protocol
            /*doc = Jsoup.connect("http://google.com").get();*/
            doc = Jsoup.connect("http://finance.yahoo.com/quote/"+stock+"/history?p="+stock).get();

            // get page title
            String title = doc.title();
            System.out.println("title : " + title);

            // get all headers
            Elements links = doc.select("tr[class]");
            // get the prices
            Elements links2 = doc.select("tbody");
            for (Element link : links) {

/*
                // get the value from href attribute
                System.out.println("link : " + link.attr("href") + "\n\n");
                //  System.out.println("text : " + link.text());
                System.out.println("\"\\nlink : \" + link.attr(\"href\") + \"\\n\" + \"text : \" + link.text()");
*/
                System.out.println(header = link.getElementsByClass("C($tertiaryColor) Fz(xs) Ta(end)").text()); // Gets the header

                for (Element link2 : links2){

                    System.out.println(prices = link2.getElementsByClass("BdT Bdc($seperatorColor) Ta(end) Fz(s) Whs(nw)").text()); // gets the prices
                    //System.out.println(link2.getElementsByClass("BdT Bdc($seperatorColor) Ta(end) Fz(s) Whs(nw):Span").text() );
                    return (stock + " " + header + "\n\t\r" + prices + "\n\t\r" + setStockMessage);
                }

                //System.out.println(link.attr("href") + "\n" + "text : " + link.text() + "Data: " + link.attr("href"));

                //return (doc.title().toString() + "\n\t\r" + doc.text() + "\n\t\r");
                //return header + "%n" + prices;



            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        return "done";
    }
}

